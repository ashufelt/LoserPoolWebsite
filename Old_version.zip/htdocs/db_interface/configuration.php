<?php

namespace Configuration;

class Config
{
    static public $host = "sql310.infinityfree.com";
    const USER = "if0_34807647";
    const PASS = "3pzOJOHlUKkV2d";
    const LPDB = "if0_34807647_lpdb";
}
