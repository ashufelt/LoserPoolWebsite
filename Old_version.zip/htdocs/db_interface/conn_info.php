<?php

namespace ConnectionInfo;

const PICKS_DB_NAME = 'LPDP';
const HOST = "localhost";
const PASS = "M7ajs5grn3!";
const USER = "root";


function get_picks_db_name()
{
    return 'LPDP';
}

function get_host()
{
    return 'localhost';
}

function get_pass()
{
    return 'M7ajs5grn3!';
}

function get_user()
{
    return 'root';
}
